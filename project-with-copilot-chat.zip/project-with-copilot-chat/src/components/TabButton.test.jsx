describe('TabButton', () => {
  it('renders without crashing', () => {
    const div = document.createElement('div');
    ReactDOM.render(<TabButton onSelect={() => {}} isSelected={false}>Tab 1</TabButton>, div);
    ReactDOM.unmountComponentAtNode(div);
  });

  it('renders the correct text', () => {
    const { getByText } = render(<TabButton onSelect={() => {}} isSelected={false}>Tab 1</TabButton>);
    expect(getByText('Tab 1')).toBeInTheDocument();
  });

  it('applies the active class when isSelected is true', () => {
    const { getByRole } = render(<TabButton onSelect={() => {}} isSelected={true}>Tab 1</TabButton>);
    expect(getByRole('button')).toHaveClass('active');
  });

  it('does not apply the active class when isSelected is false', () => {
    const { getByRole } = render(<TabButton onSelect={() => {}} isSelected={false}>Tab 1</TabButton>);
    expect(getByRole('button')).not.toHaveClass('active');
  });

  it('calls onSelect when the button is clicked', () => {
    const handleClick = jest.fn();
    const { getByRole } = render(<TabButton onSelect={handleClick} isSelected={false}>Tab 1</TabButton>);
    fireEvent.click(getByRole('button'));
    expect(handleClick).toHaveBeenCalled();
  });
});