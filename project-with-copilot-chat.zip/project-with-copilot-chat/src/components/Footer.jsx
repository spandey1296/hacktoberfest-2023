// An exported Footer component that displays my name "Maximilian Schwarzmüller" and the copyright sign.
// The Footer component should be rendered in the App component.

export default function Footer() {
  return (
    <footer>
      <p>&copy; 2023</p>
      <p>Maximilian Schwarzmüller</p>
    </footer>
  );
}
